/* SPDX-License-Identifier: GPL-2.0 */
#ifndef BCM63XX_DEV_UART_H_
#define BCM63XX_DEV_UART_H_

int bcm63xx_uart_register(unsigned int id);

#endif /* BCM63XX_DEV_UART_H_ */
