/* SPDX-License-Identifier: GPL-2.0 */
// Copyright (C) 2018 Hangzhou C-SKY Microsystems co.,ltd.

#ifndef __ASM_CSKY_SHMPARAM_H
#define __ASM_CSKY_SHMPARAM_H

#define SHMLBA	(4 * PAGE_SIZE)

#define __ARCH_FORCE_SHMLBA

#endif /* __ASM_CSKY_SHMPARAM_H */
