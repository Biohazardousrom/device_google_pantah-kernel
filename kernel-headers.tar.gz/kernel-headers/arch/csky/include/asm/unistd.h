/* SPDX-License-Identifier: GPL-2.0 */
// Copyright (C) 2018 Hangzhou C-SKY Microsystems co.,ltd.

#include <uapi/asm/unistd.h>

#define NR_syscalls (__NR_syscalls)
